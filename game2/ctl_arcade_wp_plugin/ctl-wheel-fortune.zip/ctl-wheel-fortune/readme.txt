=== CTL Wheel of Fortune ===
Tags: 	casino game, gambling game, html5 gambling, instant win, lottery, lucky, lucky game, poker, slot, sweepstakes
Requires at least: 4.3
Tested up to: 4.3

Add Wheel of Fortune to CTL Arcade plugin

== Description ==
Add Wheel of Fortune to CTL Arcade plugin